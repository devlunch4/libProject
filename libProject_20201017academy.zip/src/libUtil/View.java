package libUtil;

public class View {

	// 각 메소드를 호출로 변환 하는 도움 클래스 및 메소드

	// 첫메인화면
	public static final int HOME = 0;
	// 회원로그인
	public static final int USERLOGIN = 1;
	// 회원로그인 완료후
	public static final int USERMENU = 2;
	// 회원의 도서검색
	public static final int USERBOOKSEARCH = 3;
	// 회원의 도서신청 게시판 보기 및 수정
	public static final int APPLYBOARDSHOW = 4;
	// 회원 정보수정 메뉴
	public static final int USEREDIT = 5;
	// 회원 책기간 연장 메소드 전 메뉴 연결
	public static final int USERBOOKEXT = 6;
	// 회원 공지글 메소드 호출
	public static final int USERREADBOARD = 7;
	//
	// 관리자로그인
	// 관리자로그인
	// 관리자로그인
	public static final int ADMINLOGIN = 8;
	//로그인후 메뉴
	public static final int ADMINMENU = 9;
	
	//
	public static final int BOARD_LIST = 9;
	
	
	
	
	
	//
	public static final int BOARD_VIEW = 10;
	//
	public static final int BOARD_INSERT_FORM = 11;

}
